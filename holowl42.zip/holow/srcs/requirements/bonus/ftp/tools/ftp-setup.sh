#!/bin/sh

echo "Inception: A iniciar o script de configuração do FTP..."

# 1. Criar a pasta segura do vsftpd caso não exista (exigência do programa)
mkdir -p /var/run/vsftpd/empty

# 2. Criar as configurações base seguras no ficheiro vsftpd.conf
cat << EOF > /etc/vsftpd.conf
# Ativar o daemon em primeiro plano (PID 1 legítimo)
listen=YES
listen_run_as_launching_user=NO
background=NO

# Permissões de escrita e utilizadores locais
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022

# Trancar o utilizador estritamente dentro da sua pasta raiz (Chroot)
chroot_local_user=YES
allow_writeable_chroot=YES

# Configuração do Modo Passivo (Obrigatório para funcionar atrás do Docker)
pasv_enable=YES
pasv_min_port=21100
pasv_max_port=21105
pasv_address=127.0.0.1
secure_chroot_dir=/var/run/vsftpd/empty
EOF

# 3. Criar o utilizador FTP dinamicamente se ele não existir no sistema
# Usamos o utilizador do WP e a password do utilizador regular (ou cria uma nova no .env)
if ! id "$WP_USER" >/dev/null 2>&1; then
    echo "Inception: A criar utilizador FTP: $WP_USER"
    
    # Cria o utilizador com a pasta raiz apontando para o WordPress e sem shell de sistema por segurança
    useradd -m -d /var/www/wordpress -s /bin/false $WP_USER
    
    # Define a password do utilizador extraída das tuas variáveis
    echo "$WP_USER:$WP_USER_PASSWORD" | chpasswd
    
    # Garante que a pasta pertence ao utilizador e ao grupo web www-data
    chown -R $WP_USER:www-data /var/www/wordpress
fi

echo "✔ Servidor FTP configurado. A iniciar o serviço..."
exec vsftpd /etc/vsftpd.conf
