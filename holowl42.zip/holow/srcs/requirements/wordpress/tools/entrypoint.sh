#!/bin/bash

echo "Inception: A iniciar configuração do WordPress..."

# 1. Loop de espera - CORRIGIDO: Agora lê a password diretamente do Secret montado na RAM
echo "WordPress: A aguardar ligação à base de dados (${DB_HOST})..."
while ! mariadb-admin ping -h"${DB_HOST}" -u"${DB_USER}" -p"$(cat /run/secrets/db_password)" --silent; do
    sleep 2
done
echo "WordPress: Conexão com o MariaDB estabelecida!"

# Garante que a pasta existe antes de entrar nela
mkdir -p $WP_PATH
cd $WP_PATH

# 2. SE A PASTA ESTIVER VAZIA, FAZ O DOWNLOAD DO WORDPRESS PRIMEIRO
if [ ! -f "wp-config-sample.php" ]; then
    echo "Inception: Pasta vazia. A descarregar ficheiros do WordPress..."
    wp core download --path="." --allow-root
fi

# 3. Criação e injeção do ficheiro wp-config.php
if [ -f wp-config.php ] && wp config has DB_PASSWORD --allow-root; then
    echo "wp-config.php is found"
else
    # Copia o modelo base
    cp wp-config-sample.php wp-config.php

    # Extrai as passwords reais de dentro dos ficheiros dos Secrets da RAM
    REAL_DB_PASSWORD=$(cat /run/secrets/db_password)
    REAL_WP_ADMIN_PASSWORD=$(cat /run/secrets/wp_admin_password)
    REAL_WP_USER_PASSWORD=$(cat /run/secrets/wp_user_password)

    # Injeta os valores corretos no wp-config.php
    wp config set DB_HOST "$DB_HOST" --allow-root --path="."
    wp config set DB_NAME "$DB_DATABASE" --allow-root --path="."
    wp config set DB_USER "$DB_USER" --allow-root --path="."
    wp config set DB_PASSWORD "$REAL_DB_PASSWORD" --allow-root --path="."
    wp config set table_prefix "$DB_TABLE_PREFIX" --allow-root --path="."
    wp config set WP_DEBUG false --raw --allow-root --path="."
    wp config set WP_DEBUG_LOG false --raw --allow-root --path="."

    wp config shuffle-salts --allow-root
    echo "wp-config.php file generated"

    echo "Installing Wordpress"
    wp core install --allow-root \
        --path="." \
        --url="$DOMAIN_NAME" \
        --title="$WP_TITLE" \
        --admin_user="$WP_ADMIN" \
        --admin_password="$REAL_WP_ADMIN_PASSWORD" \
        --admin_email="$WP_ADMIN_EMAIL"
        
    wp plugin update --path="." --allow-root --all

    wp user create "$WP_USER" "$WP_USER_EMAIL" \
        --user_pass="$REAL_WP_USER_PASSWORD" \
        --role=author \
        --porcelain \
        --allow-root --path="."
fi

# Ajusta as permissões de forma correta para o Nginx conseguir ler
chown -R www-data:www-data /var/www/wordpress
mkdir -p /run/php
chown -R www-data:www-data /run/php


# adiçao da parte do bonus 

# ======================================================================
# CONFIGURAÇÃO DO BÓNUS REDIS (Adicionar antes do comando final 'exec')
# ======================================================================
echo "Inception: A configurar o bónus Redis Cache..."

wp config set WP_REDIS_HOST "redis" --allow-root --path="."
wp config set WP_REDIS_PORT "6379" --raw --allow-root --path="."

wp plugin install redis-cache --activate --allow-root --path="."

wp redis enable --allow-root --path="."
echo "✔ Bónus Redis Cache ativado com sucesso!"

echo "WordPress: A iniciar o PHP-FPM em primeiro plano..."
exec /usr/sbin/php-fpm8.2 -F
