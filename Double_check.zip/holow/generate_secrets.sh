#!/bin/bash
# generate_secrets.sh — Gera senhas fortes para os Docker Secrets
# Uso: ./generate_secrets.sh
# NÃO commitar os secrets gerados (secrets/ está no .gitignore)

set -eu

SECRETS_DIR="./secrets"
mkdir -p "$SECRETS_DIR"

gen() {
    openssl rand -base64 32 | tr -d '/+=' | cut -c1-24
}

echo "A gerar senhas fortes..."

if [ -f "$SECRETS_DIR/db_password.txt" ]; then
    echo "⚠  Secrets já existem. A sobrescrever..."
fi

echo "$(gen)" > "$SECRETS_DIR/db_password.txt"
echo "$(gen)" > "$SECRETS_DIR/db_root_password.txt"
echo "$(gen)" > "$SECRETS_DIR/wp_admin_password.txt"
echo "$(gen)" > "$SECRETS_DIR/wp_user_password.txt"
echo "$(gen)" > "$SECRETS_DIR/ftp_password.txt"

chmod 600 "$SECRETS_DIR"/*.txt

echo "✔ Senhas geradas em $SECRETS_DIR/"
echo "⚠  Guarda-as em local seguro. NÃO commitar."